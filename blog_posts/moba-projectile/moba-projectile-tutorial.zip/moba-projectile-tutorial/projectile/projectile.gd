class_name Projectile
extends Node3D
## Flies toward a target node (homing), plays an impact when it gets there, then lets its
## trail and embers fade out before freeing itself.

signal arrived(at: Vector3)

@export var speed := 14.0
## Close enough to count as a hit.
@export var hit_radius := 0.35
## Where on the target to aim (chest height).
@export var aim_offset := Vector3(0, 1.0, 0)
@export var impact_scene: PackedScene
## false = the impact plays its flash only.
@export var full_impact := true

var target: Node3D
var _flying := false

@onready var _visual: Node3D = $Visual
@onready var _trail: Trail = $Trail
@onready var _embers: GPUParticles3D = $Embers


func launch(from: Vector3, to: Node3D) -> void:
	global_position = from
	target = to
	_flying = true
	_embers.emitting = _embers.visible


func _physics_process(delta: float) -> void:
	if not _flying:
		return
	if not is_instance_valid(target):
		_finish(global_position)
		return
	var aim := target.global_position + aim_offset
	var to_target := aim - global_position
	var step := speed * delta
	if to_target.length() <= maxf(step, hit_radius):
		_finish(aim)
		return
	global_position += to_target.normalized() * step


func _finish(at: Vector3) -> void:
	_flying = false
	# Hide the head right away, but let the trail and the embers die out on their own.
	_visual.visible = false
	_trail.emitting = false
	_embers.emitting = false
	if impact_scene:
		var fx: Node3D = impact_scene.instantiate()
		fx.set(&"full", full_impact)
		get_parent().add_child(fx)
		fx.global_position = at
	arrived.emit(at)
	await get_tree().create_timer(0.8).timeout
	queue_free()
