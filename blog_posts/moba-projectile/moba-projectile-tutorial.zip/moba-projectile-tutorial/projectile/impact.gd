extends Node3D
## Impact: a flash that pops and shrinks, a ring that expands on the floor, a burst of
## sparks and a quick light. Everything is timed from one clock so it reads as one hit.

## false = flash only (the simple version from step 5 of the tutorial).
@export var full := true
@export var lifetime := 0.55

var _t := 0.0

@onready var _flash: GeometryInstance3D = $Flash
@onready var _ring: GeometryInstance3D = $Ring
@onready var _sparks: GPUParticles3D = $Sparks
@onready var _light: OmniLight3D = $Light


func _ready() -> void:
	_ring.visible = full
	_sparks.visible = full
	_light.visible = full
	# The ring lies on the floor even when the hit lands at chest height.
	_ring.global_position.y = 0.03
	if full:
		_sparks.restart()
	_update()


func _process(delta: float) -> void:
	_t += delta
	_update()
	if _t > lifetime + 0.5:
		queue_free()


func _update() -> void:
	var k := clampf(_t / lifetime, 0.0, 1.0)
	# Flash: biggest on the first frame, then shrinks and fades in about 0.12 s.
	var f := clampf(_t / 0.12, 0.0, 1.0)
	_flash.scale = Vector3.ONE * lerpf(1.8, 0.6, f)
	_flash.set_instance_shader_parameter(&"fade", 1.0 - f)
	# Ring: fast at first, then slows down (ease-out), fading as it grows.
	var e := 1.0 - pow(1.0 - k, 3.0)
	_ring.scale = Vector3.ONE * lerpf(0.4, 3.2, e)
	_ring.set_instance_shader_parameter(&"fade", 1.0 - k)
	_light.light_energy = 8.0 * (1.0 - f)
