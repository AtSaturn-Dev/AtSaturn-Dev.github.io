class_name Trail
extends MeshInstance3D
## Camera-facing ribbon that follows its parent. Each point remembers when it was made,
## and points older than `lifetime` drop off the tail.

@export var lifetime := 0.35
@export var width := 0.55
## Don't add a point until the head has moved this far.
@export var min_distance := 0.08

var emitting := true

var _points: PackedVector3Array = []
var _ages: PackedFloat32Array = []
var _mesh := ImmediateMesh.new()


func _ready() -> void:
	mesh = _mesh
	# The ribbon lives in world space, so it doesn't drag along with the projectile.
	top_level = true
	global_transform = Transform3D.IDENTITY


func _process(delta: float) -> void:
	for i in _ages.size():
		_ages[i] += delta
	# Old points fall off the tail.
	while _ages.size() > 0 and _ages[_ages.size() - 1] > lifetime:
		_points.remove_at(_points.size() - 1)
		_ages.remove_at(_ages.size() - 1)
	if emitting:
		var head := (get_parent() as Node3D).global_position
		if _points.is_empty() or _points[0].distance_to(head) > min_distance:
			_points.insert(0, head)
			_ages.insert(0, 0.0)
		else:
			# Keep the newest point glued to the head so the ribbon never lags behind it.
			_points[0] = head
	_rebuild()


func _rebuild() -> void:
	_mesh.clear_surfaces()
	var cam := get_viewport().get_camera_3d()
	if _points.size() < 2 or cam == null:
		return
	_mesh.surface_begin(Mesh.PRIMITIVE_TRIANGLE_STRIP)
	for i in _points.size():
		var p := _points[i]
		# Direction along the ribbon, from the neighbours on each side (smooth through curves).
		var dir := _points[maxi(i - 1, 0)] - _points[mini(i + 1, _points.size() - 1)]
		var to_cam := cam.global_position - p
		# The sideways vector faces the camera, so the strip is never seen edge-on.
		var side := dir.cross(to_cam).normalized()
		var age := clampf(_ages[i] / lifetime, 0.0, 1.0)
		var w := width * (1.0 - age * age)
		_mesh.surface_set_uv(Vector2(age, 0.0))
		_mesh.surface_add_vertex(p + side * w * 0.5)
		_mesh.surface_set_uv(Vector2(age, 1.0))
		_mesh.surface_add_vertex(p - side * w * 0.5)
	_mesh.surface_end()
