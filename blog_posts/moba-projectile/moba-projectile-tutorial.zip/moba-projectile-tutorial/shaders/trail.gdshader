// The ribbon behind the projectile. UV.x = age (0 at the head, 1 at the tail), UV.y = across.
shader_type spatial;
render_mode blend_add, unshaded, depth_draw_never, cull_disabled, shadows_disabled;

uniform vec4 head_color : source_color = vec4(1.0, 0.85, 0.5, 1.0);
uniform vec4 tail_color : source_color = vec4(1.0, 0.22, 0.02, 1.0);
uniform float intensity = 2.2;
// Noise sliding along the ribbon makes it look like it flows instead of being a flat strip.
uniform float scroll_speed = 4.0;
uniform float breakup : hint_range(0.0, 1.0) = 0.55;

float hash(vec2 p) {
	return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	vec2 u = f * f * (3.0 - 2.0 * f);
	return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x),
			mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x), u.y);
}

void fragment() {
	float age = UV.x;
	float across = abs(UV.y * 2.0 - 1.0);
	// Soft edges, brightest along the middle.
	float body = 1.0 - smoothstep(0.15, 1.0, across);
	float n = noise(vec2(UV.x * 7.0 - TIME * scroll_speed, UV.y * 3.0));
	// Fade toward the tail, and let the noise eat the tail first.
	float m = body * (1.0 - age);
	m *= mix(1.0, smoothstep(age * 0.9, age * 0.9 + 0.35, n), breakup);
	vec3 col = mix(head_color.rgb, tail_color.rgb, smoothstep(0.0, 0.6, age));
	ALBEDO = col * intensity;
	ALPHA = clamp(m, 0.0, 1.0);
}
