// A soft, glowing blob drawn on a quad that always faces the camera.
// Used for the projectile core, its halo and the impact flash.
shader_type spatial;
render_mode blend_add, unshaded, depth_draw_never, cull_disabled, shadows_disabled;

// White-hot middle, saturated body. The value step between them is what sells "energy".
uniform vec4 core_color : source_color = vec4(1.0, 0.92, 0.75, 1.0);
uniform vec4 edge_color : source_color = vec4(1.0, 0.36, 0.06, 1.0);
// Above 1.0 so the glow post effect picks it up.
uniform float intensity = 3.0;
// Higher = tighter, harder falloff.
uniform float softness : hint_range(0.5, 8.0) = 2.5;
// How much the outline wobbles. 0 = a perfect circle.
uniform float wobble : hint_range(0.0, 0.5) = 0.12;
uniform float wobble_speed = 5.0;
// Set per object from code (impact flash fading out).
instance uniform float fade = 1.0;

float hash(vec2 p) {
	return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	vec2 u = f * f * (3.0 - 2.0 * f);
	return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x),
			mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x), u.y);
}

void vertex() {
	// Billboard: swap the model's rotation for the camera's, keep position and scale.
	MODELVIEW_MATRIX = VIEW_MATRIX * mat4(INV_VIEW_MATRIX[0], INV_VIEW_MATRIX[1], INV_VIEW_MATRIX[2], MODEL_MATRIX[3]);
	MODELVIEW_MATRIX = MODELVIEW_MATRIX * mat4(
			vec4(length(MODEL_MATRIX[0].xyz), 0.0, 0.0, 0.0),
			vec4(0.0, length(MODEL_MATRIX[1].xyz), 0.0, 0.0),
			vec4(0.0, 0.0, length(MODEL_MATRIX[2].xyz), 0.0),
			vec4(0.0, 0.0, 0.0, 1.0));
}

void fragment() {
	vec2 p = UV * 2.0 - 1.0;
	// Wobble the radius with noise sampled around the circle, so the edge boils.
	float angle = atan(p.y, p.x);
	float n = noise(vec2(angle * 2.0 + 10.0, TIME * wobble_speed));
	float r = length(p) * (1.0 + (n - 0.5) * wobble * 2.0);
	float m = pow(clamp(1.0 - r, 0.0, 1.0), softness);
	vec3 col = mix(edge_color.rgb, core_color.rgb, smoothstep(0.35, 0.9, m));
	ALBEDO = col * intensity * fade;
	ALPHA = m * fade;
}
