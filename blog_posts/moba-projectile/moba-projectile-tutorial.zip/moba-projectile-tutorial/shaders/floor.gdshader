// Dark checker floor for the test scene.
shader_type spatial;

uniform vec3 color_a : source_color = vec3(0.10, 0.10, 0.11);
uniform vec3 color_b : source_color = vec3(0.14, 0.14, 0.15);

varying vec3 world_pos;

void vertex() {
	world_pos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

void fragment() {
	vec2 cell = floor(world_pos.xz);
	ALBEDO = mix(color_a, color_b, mod(cell.x + cell.y, 2.0));
	ROUGHNESS = 0.9;
}
