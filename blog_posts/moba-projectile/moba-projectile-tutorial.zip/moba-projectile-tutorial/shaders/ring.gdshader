// A thin ring for the impact shockwave. Lies flat on a PlaneMesh.
shader_type spatial;
render_mode blend_add, unshaded, depth_draw_never, cull_disabled, shadows_disabled;

uniform vec4 color : source_color = vec4(1.0, 0.55, 0.15, 1.0);
uniform float intensity = 2.5;
uniform float radius : hint_range(0.1, 1.0) = 0.8;
uniform float thickness : hint_range(0.01, 0.3) = 0.07;
instance uniform float fade = 1.0;

void fragment() {
	float r = length(UV * 2.0 - 1.0);
	// Sharp outer edge, softer inner one: reads as a wave pushing outward.
	float d = r - radius;
	float w = d > 0.0 ? thickness * 0.5 : thickness * 1.6;
	float ring = exp(-(d * d) / (w * w));
	ALBEDO = color.rgb * intensity * fade;
	ALPHA = ring * fade;
}
