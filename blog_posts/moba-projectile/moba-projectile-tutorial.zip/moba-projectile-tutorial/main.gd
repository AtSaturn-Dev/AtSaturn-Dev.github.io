extends Node3D
## Test scene: the caster fires at the target on a loop. `step` turns on the parts of the
## projectile one at a time, matching the sections of the tutorial:
##   1 plain sphere   2 glow shader   3 trail   4 embers   5 impact flash   6 full polish
## Run with `++ step=3` to start on a step, `++ shots=2` to quit after two shots.

const PROJECTILE := preload("res://projectile/projectile.tscn")
const IMPACT := preload("res://projectile/impact.tscn")

@export_range(1, 6) var step := 6
@export var interval := 1.5

var _timer := 0.4
var _time := 0.0
var _shots_left := -1
var _shake := 0.0
var _cam_home: Transform3D

@onready var _caster: Node3D = $Caster
@onready var _target: Node3D = $Target
@onready var _camera: Camera3D = $Camera3D


func _ready() -> void:
	_cam_home = _camera.transform
	for a in OS.get_cmdline_user_args():
		if a.begins_with("step="):
			step = clampi(a.substr(5).to_int(), 1, 6)
		elif a.begins_with("shots="):
			_shots_left = a.substr(6).to_int()


func _process(delta: float) -> void:
	_time += delta
	# The target strafes so you can see the homing.
	_target.position.z = sin(_time * 1.2) * 1.8
	_timer -= delta
	if _timer <= 0.0:
		if _shots_left == 0:
			get_tree().quit()
			return
		_timer = interval
		_fire()
		_shots_left -= 1
	# Camera shake: random offset that dies out quickly.
	_shake = maxf(_shake - delta * 3.0, 0.0)
	var s := _shake * _shake
	_camera.transform = _cam_home.translated_local(Vector3(randf_range(-1, 1), randf_range(-1, 1), 0.0) * s * 0.25)


func _fire() -> void:
	var p: Projectile = PROJECTILE.instantiate()
	add_child(p)
	var visual := p.get_node(^"Visual")
	visual.get_node(^"Sphere").visible = step == 1
	visual.get_node(^"Core").visible = step >= 2
	visual.get_node(^"Halo").visible = step >= 2
	visual.get_node(^"Light").visible = step >= 6
	p.get_node(^"Trail").visible = step >= 3
	p.get_node(^"Embers").visible = step >= 4
	p.impact_scene = IMPACT if step >= 5 else null
	p.full_impact = step >= 6
	var muzzle := _caster.global_position + Vector3(0.6, 1.0, 0.0)
	p.launch(muzzle, _target)
	p.arrived.connect(_on_arrived)
	if step >= 6:
		# A small flash at the hand sells the release.
		var cast: Node3D = IMPACT.instantiate()
		cast.full = false
		cast.scale = Vector3.ONE * 0.45
		add_child(cast)
		cast.global_position = muzzle


func _on_arrived(_at: Vector3) -> void:
	if step >= 6:
		_shake = 0.6
